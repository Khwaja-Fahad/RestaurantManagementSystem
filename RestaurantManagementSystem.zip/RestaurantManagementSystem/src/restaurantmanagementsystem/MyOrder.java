package restaurantmanagementsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class MyOrder extends JFrame {
    public static final String ORDER_FILE = "order.txt";

    public MyOrder(List<String> cartItems) {
        setTitle("My Order");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color
        getContentPane().setLayout(new BorderLayout());

        JPanel orderItemsPanel = new JPanel(new BorderLayout());
        getContentPane().add(orderItemsPanel, BorderLayout.CENTER);

        // Table to display order items
        String[] columnNames = {"Dish Name", "Price"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        orderItemsPanel.add(scrollPane, BorderLayout.CENTER);

        // Read items from file and add to the table
        double totalBill = 0.0; // Initialize total bill
        if (!cartItems.isEmpty()) {
            for (String line : cartItems) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    model.addRow(parts);
                    totalBill += Double.parseDouble(parts[1]); // Add price to total bill
                }
            }
        } else {
            JLabel emptyLabel = new JLabel("You have no order now.");
            emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
            orderItemsPanel.add(emptyLabel, BorderLayout.CENTER);
        }

        // Display total bill
        JLabel totalBillLabel = new JLabel("Total Bill: $" + totalBill);
        totalBillLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalBillLabel.setHorizontalAlignment(SwingConstants.CENTER);
        orderItemsPanel.add(totalBillLabel, BorderLayout.SOUTH);

        // Add buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(173, 216, 230));

        // Go Back button
        JButton goBackButton = new JButton("Go Back");
        goBackButton.setBackground(new Color(173, 216, 230));
        goBackButton.setForeground(Color.BLACK);
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new MainScreen().setVisible(true); // Go back to the MainScreen
            }
        });
        buttonPanel.add(goBackButton);

        // Clear Order button
        JButton clearOrderButton = new JButton("Clear Order");
        clearOrderButton.setBackground(new Color(173, 216, 230));
        clearOrderButton.setForeground(Color.BLACK);
        clearOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearOrder();
            }
        });
        buttonPanel.add(clearOrderButton);

        // Payment button
        JButton paymentButton = new JButton("Payment");
        paymentButton.setBackground(new Color(173, 216, 230));
        paymentButton.setForeground(Color.BLACK);
        paymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Gather payment details from the user
                JTextField cardNumberField = new JTextField(20);
                JTextField expirationDateField = new JTextField(6);
                JTextField cvvField = new JTextField(3);

                JPanel paymentPanel = new JPanel();
                paymentPanel.setLayout(new GridLayout(3, 2));
                paymentPanel.add(new JLabel("Card Number:"));
                paymentPanel.add(cardNumberField);
                paymentPanel.add(new JLabel("Expiration Date (MM/YY):"));
                paymentPanel.add(expirationDateField);
                paymentPanel.add(new JLabel("CVV:"));
                paymentPanel.add(cvvField);

                int result = JOptionPane.showConfirmDialog(null, paymentPanel,
                        "Enter Payment Details", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    String cardNumber = cardNumberField.getText();
                    String expirationDate = expirationDateField.getText();
                    String cvv = cvvField.getText();

                    // Validate payment details (you can add your validation logic here)

                    // Proceed with payment processing
                    processPayment(cardNumber, expirationDate, cvv);
                }
            }
        });
        buttonPanel.add(paymentButton);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void clearOrder() {
        // Clear the order file
        try {
            FileWriter writer = new FileWriter(ORDER_FILE);
            writer.write(""); // Clear the order file
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        dispose(); // Close the MyOrder window after clearing the order
    }

    private void processPayment(String cardNumber, String expirationDate, String cvv) {
        // Add your payment processing logic here
        // This method will be called when the user enters payment details and clicks OK
        // You can integrate with a payment gateway or simulate a payment transaction
        // For now, let's just print the payment details to console
        System.out.println("Card Number: " + cardNumber);
        System.out.println("Expiration Date: " + expirationDate);
        System.out.println("CVV: " + cvv);
        // You can also add further steps like order confirmation, updating databases, etc.
        JOptionPane.showMessageDialog(null, "Payment processed successfully!");
    }

    public static void main(String[] args) {
        // Example usage
        // Create a list of items in the cart
        List<String> cartItems = List.of("Pizza,10.99", "Burger,5.99", "Salad,4.99");
        // Open the MyOrder window with the cart items
        new MyOrder(cartItems);
    }
}
