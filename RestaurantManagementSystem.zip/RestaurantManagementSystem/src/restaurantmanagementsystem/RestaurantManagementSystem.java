package restaurantmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RestaurantManagementSystem extends JFrame {
    public RestaurantManagementSystem() {
        setTitle("Welcome to Restaurant System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        panel.setBackground(new Color(173, 216, 230)); // Light blue background color

        JLabel titleLabel = new JLabel("Welcome to Restaurant System!");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Set font and size
        titleLabel.setForeground(Color.BLACK); // Set text color
        panel.add(titleLabel);

        // Add space between the welcome note and buttons
        panel.add(Box.createVerticalStrut(30));

        JButton loginButton = createStyledButton("Login", 250, 50); // Increased size for login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Login();
                dispose(); // Close the WelcomeFrame
            }
        });
        panel.add(loginButton);

        // Add space between the login button and registration button
        panel.add(Box.createVerticalStrut(20));

        JButton registerButton = createStyledButton("Register", 250, 50); // Increased size for registration button
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Registration(RestaurantManagementSystem.this); // Pass reference to main page
                setVisible(false); // Hide the main page
            }
        });
        panel.add(registerButton);

        add(panel);
        setLocationRelativeTo(null); // Center the frame on the screen
        setVisible(true); // Make the frame visible
    }

    private JButton createStyledButton(String buttonText, int width, int height) {
        JButton button = new JButton(buttonText);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(width, height)); // Set specified width and height
        button.setBackground(new Color(173, 216, 230)); // Light blue button color
        button.setForeground(Color.BLACK); // Set text color

        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(135, 206, 250)); // Light blue color on hover
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(173, 216, 230)); // Restore original color
            }
        });

        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new RestaurantManagementSystem();
            }
        });
    }
}
