package restaurantmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Menu extends JFrame {
    private static final String MENU_FILE = "menu.txt";
    private static final String CART_FILE = "cart.txt";
    private static final String IMAGE_FOLDER = "restaurantmanagementsystem/image/";

    public Menu() {
        setTitle("Menu");
        setSize(600, 800); // Increased frame size
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 1, 10, 10)); // Changed to 0 rows to accommodate variable number of dishes
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(173, 216, 230)); // Light blue background color

        loadDishes(panel);

        JScrollPane scrollPane = new JScrollPane(panel); // Add a scroll pane to handle overflow
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Always show vertical scrollbar
        add(scrollPane);
        
        
JButton goBackButton = new JButton("Go Back");
goBackButton.setPreferredSize(new Dimension(150, 40)); // Adjusted size to match other buttons
goBackButton.setBackground(new Color(173, 216, 230)); // Light blue button color
goBackButton.setForeground(Color.BLACK); // Set text color
goBackButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        dispose(); // Close the Menu window
        new MainScreen(); // Open the MainScreen
    }
});
panel.add(goBackButton); // Add the "Go Back" button to the panel



        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadDishes(JPanel panel) {
        List<String> dishNames = readDishNamesFromFile();
        for (String dish : dishNames) {
            JPanel dishPanel = new JPanel(new BorderLayout());
            dishPanel.setBackground(new Color(173, 216, 230)); // Light blue background color

           ImageIcon dishImage = new ImageIcon(getResourcePath(dish + ".jpg"));

            // Resize image to fit within the panel
            Image image = dishImage.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
            dishImage = new ImageIcon(image);
            JLabel imageLabel = new JLabel(dishImage);
            dishPanel.add(imageLabel, BorderLayout.CENTER); // Added image label to center

            JLabel nameLabel = new JLabel("" + dish);
            nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
            dishPanel.add(nameLabel, BorderLayout.NORTH);

            JButton dishButton = new JButton("Details");
            dishButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    showDishDetails(dish);
                }
            });
            dishButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            dishButton.setBackground(new Color(173, 216, 230)); // Light blue button color
            dishButton.setForeground(Color.BLACK); // Set text color
            dishButton.setPreferredSize(new Dimension(200, 40));
            dishPanel.add(dishButton, BorderLayout.SOUTH); // Added dish button to bottom

            panel.add(dishPanel);
        }
    }

    private List<String> readDishNamesFromFile() {
        List<String> dishNames = new ArrayList<>();
        dishNames.add("Spaghetti Bolognese");
        dishNames.add("Chicken Alfredo");
        dishNames.add("Margherita Pizza");
        dishNames.add("Caesar Salad");
        dishNames.add("Beef Stir-Fry");
        dishNames.add("Grilled Salmon");
        dishNames.add("Vegetable Lasagna");
        dishNames.add("Beef Burger");
        dishNames.add("Chicken Caesar Wrap");
        dishNames.add("Mushroom Risotto");
        dishNames.add("Chicken Tikka Masala");
        dishNames.add("Shrimp Scampi");
        dishNames.add("Thai Green Curry");
        dishNames.add("Caprese Salad");
        dishNames.add("Vegetable Pad Thai");
        dishNames.add("BBQ Ribs");
        dishNames.add("Tiramisu");
        dishNames.add("Cheesecake");
        dishNames.add("Chocolate Lava Cake");
        dishNames.add("Mojito");
        return dishNames;
    }

    private void showDishDetails(String dish) {
        JFrame dishDetailsFrame = new JFrame(dish);
        dishDetailsFrame.setSize(600, 400);
        dishDetailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dishDetailsFrame.getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color
        dishDetailsFrame.setLayout(new BorderLayout());

        String ingredients = getIngredients(dish);
        double price = getPrice(dish);

        JTextArea detailsArea = new JTextArea("Ingredients: \n" + ingredients);
        detailsArea.setFont(new Font("Arial", Font.BOLD, 12)); // Set font to bold
        detailsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(detailsArea);
        dishDetailsFrame.add(scrollPane, BorderLayout.CENTER);

        JLabel priceLabel = new JLabel("Price: $" + price);
        priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
        priceLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Set font to bold and increase font size
        priceLabel.setBackground(Color.YELLOW); // Highlight the price label
        priceLabel.setOpaque(true); // Make label opaque to show background color
        dishDetailsFrame.add(priceLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        buttonPanel.setBackground(new Color(173, 216, 230)); // Light blue background color

        JButton editButton = new JButton("Edit Ingredients");
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                detailsArea.setEditable(true);
            }
        });
        buttonPanel.add(editButton);

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveEditedIngredients(dish, detailsArea.getText());
                detailsArea.setEditable(false);
                JOptionPane.showMessageDialog(dishDetailsFrame, "Ingredients saved successfully!");
            }
        });
        buttonPanel.add(saveButton);

        JButton addToCartButton = new JButton("Add to Cart");
        addToCartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double price = getPrice(dish);

                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter(CART_FILE, true));
                    writer.write(dish + "," + price);
                    writer.newLine();
                    writer.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                JOptionPane.showMessageDialog(dishDetailsFrame, "Added to Cart: " + dish);
            }
        });
        buttonPanel.add(addToCartButton);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dishDetailsFrame.dispose();
            }
        });
        buttonPanel.add(backButton);

        dishDetailsFrame.add(buttonPanel, BorderLayout.SOUTH);

        dishDetailsFrame.setLocationRelativeTo(null);
        dishDetailsFrame.setVisible(true);
    }

    private String getIngredients(String dish) {
        String ingredients = "";
        if (dish.equals("Spaghetti Bolognese")) {
            ingredients = "Spaghetti, ground beef, onions, garlic, tomato sauce, herbs, Parmesan cheese";
        } else if (dish.equals("Chicken Alfredo")) {
            ingredients = "Fettuccine pasta, chicken breast, heavy cream, Parmesan cheese, garlic, butter";
        } else if (dish.equals("Margherita Pizza")) {
            ingredients = "Pizza dough, tomato sauce, fresh mozzarella cheese, basil leaves, olive oil";
        } else if (dish.equals("Caesar Salad")) {
            ingredients = "Romaine lettuce, Caesar dressing, croutons, Parmesan cheese";
        } else if (dish.equals("Beef Stir-Fry")) {
            ingredients = "Beef strips, mixed vegetables (bell peppers, broccoli, carrots), soy sauce, garlic, ginger";
        } else if (dish.equals("Grilled Salmon")) {
            ingredients = "Salmon fillet, lemon, olive oil, salt, pepper, herbs";
        } else if (dish.equals("Vegetable Lasagna")) {
            ingredients = "Lasagna noodles, marinara sauce, ricotta cheese, spinach, mushrooms, bell peppers, onions";
        } else if (dish.equals("Beef Burger")) {
            ingredients = "Beef patty, hamburger bun, lettuce, tomato, onion, cheese, ketchup, mustard";
        } else if (dish.equals("Chicken Caesar Wrap")) {
            ingredients = "Grilled chicken strips, romaine lettuce, Caesar dressing, Parmesan cheese, tortilla wrap";
        } else if (dish.equals("Mushroom Risotto")) {
            ingredients = "Arborio rice, mushrooms, onions, garlic, vegetable broth, Parmesan cheese, white wine";
        } else if (dish.equals("Chicken Tikka Masala")) {
            ingredients = "Chicken thighs, tomato sauce, yogurt, cream, onions, garlic, spices, basmati rice";
        } else if (dish.equals("Shrimp Scampi")) {
            ingredients = "Shrimp, linguine pasta, garlic, butter, white wine, lemon juice, parsley";
        } else if (dish.equals("Thai Green Curry")) {
            ingredients = "Chicken, coconut milk, green curry paste, bell peppers, bamboo shoots, basil leaves";
        } else if (dish.equals("Caprese Salad")) {
            ingredients = "Fresh tomatoes, fresh mozzarella cheese, basil leaves, balsamic glaze, olive oil";
        } else if (dish.equals("Vegetable Pad Thai")) {
            ingredients = "Rice noodles, tofu, bean sprouts, carrots, bell peppers, peanuts, tamarind sauce";
        } else if (dish.equals("BBQ Ribs")) {
            ingredients = "Pork ribs, BBQ sauce, coleslaw, baked beans, cornbread";
        } else if (dish.equals("Tiramisu")) {
            ingredients = "Ladyfingers, espresso, mascarpone cheese, cocoa powder, rum, sugar";
        } else if (dish.equals("Cheesecake")) {
            ingredients = "Cream cheese, graham cracker crust, sugar, eggs, vanilla extract";
        } else if (dish.equals("Chocolate Lava Cake")) {
            ingredients = "Chocolate cake, chocolate ganache, vanilla ice cream";
        } else if (dish.equals("Mojito")) {
            ingredients = "White rum, lime, mint leaves, simple syrup, soda water";
        }

        // Split ingredients by comma and format them
        String[] ingredientsArray = ingredients.split(", ");
        StringBuilder formattedIngredients = new StringBuilder();
        for (int i = 0; i < ingredientsArray.length; i++) {
            formattedIngredients.append((i + 1) + ") " + ingredientsArray[i] + "\n");
        }
        return formattedIngredients.toString().trim();
    }

    private double getPrice(String dish) {
        if (dish.equals("Spaghetti Bolognese")) {
            return 12.99;
        } else if (dish.equals("Chicken Alfredo")) {
            return 14.99;
        } else if (dish.equals("Margherita Pizza")) {
            return 10.99;
        } else if (dish.equals("Caesar Salad")) {
            return 8.99;
        } else if (dish.equals("Beef Stir-Fry")) {
            return 13.99;
        } else if (dish.equals("Grilled Salmon")) {
            return 16.99;
        } else if (dish.equals("Vegetable Lasagna")) {
            return 12.99;
        } else if (dish.equals("Beef Burger")) {
            return 11.99;
        } else if (dish.equals("Chicken Caesar Wrap")) {
            return 9.99;
        } else if (dish.equals("Mushroom Risotto")) {
            return 15.99;
        } else if (dish.equals("Chicken Tikka Masala")) {
            return 14.99;
        } else if (dish.equals("Shrimp Scampi")) {
            return 17.99;
        } else if (dish.equals("Thai Green Curry")) {
            return 13.99;
        } else if (dish.equals("Caprese Salad")) {
            return 9.99;
        } else if (dish.equals("Vegetable Pad Thai")) {
            return 12.99;
        } else if (dish.equals("BBQ Ribs")) {
            return 18.99;
        } else if (dish.equals("Tiramisu")) {
            return 7.99;
        } else if (dish.equals("Cheesecake")) {
            return 6.99;
        } else if (dish.equals("Chocolate Lava Cake")) {
            return 8.99;
        } else if (dish.equals("Mojito")) {
            return 9.99;
        } else {
            return 0.0;
        }
    }

    private void saveEditedIngredients(String dish, String editedIngredients) {
        File file = new File(MENU_FILE);
        File tempFile = new File("temp.txt");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(dish)) {
                    bw.write(dish + "," + escapeCommas(editedIngredients) + "," + getPrice(dish));
                } else {
                    bw.write(line);
                }
                bw.newLine();
            }
            br.close();
            bw.close();
            file.delete();
            tempFile.renameTo(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String escapeCommas(String ingredients) {
        return ingredients.replaceAll(",", "\\,");
    }

 private URL getResourcePath(String fileName) {
    return getClass().getClassLoader().getResource(IMAGE_FOLDER + fileName);
}



    public static void main(String[] args) {
        new Menu();
    }
}
