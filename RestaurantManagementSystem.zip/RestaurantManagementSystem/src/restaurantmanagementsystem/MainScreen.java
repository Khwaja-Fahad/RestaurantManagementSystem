package restaurantmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainScreen extends JFrame {
    private static final String CART_FILE = "cart.txt";

    public MainScreen() {
        setTitle("Main Screen");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10)); // Changed layout to accommodate all buttons
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50)); // Adjusted border
        panel.setBackground(new Color(173, 216, 230)); // Light blue background color

        // Create button action listeners outside
        ActionListener menuListener = e -> openMenu();
        ActionListener cartListener = e -> openCart(); // No need to pass the MainScreen reference
        ActionListener orderListener = e -> openMyOrder();
        ActionListener contactsListener = e -> openContacts(this); // Pass the reference to MainScreen
        ActionListener backListener = e -> goBack();

        JButton menuButton = createStyledButton("Menu", menuListener);
        JButton cartButton = createStyledButton("Cart", cartListener);
        JButton myOrderButton = createStyledButton("My Order", orderListener);
        JButton contactsButton = createStyledButton("Contacts", contactsListener);
        JButton backButton = createStyledButton("Go Back", backListener);

        panel.add(menuButton);
        panel.add(cartButton);
        panel.add(myOrderButton);
        panel.add(contactsButton);
        panel.add(backButton);

        add(panel);
        setLocationRelativeTo(null); // Center the frame on the screen
        setVisible(true); // Make the frame visible
    }

    private JButton createStyledButton(String buttonText, ActionListener listener) {
        JButton button = new JButton(buttonText);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 40));
        button.setBackground(new Color(173, 216, 230)); // Light blue button color
        button.setForeground(Color.BLACK); // Set text color
        button.addActionListener(listener); // Assign action listener
        return button;
    }

    private void openMenu() {
        new Menu();
    }

    private void openCart() {
        new Cart(this); // Pass the reference to the Cart constructor
    }

    private void openMyOrder() {
        List<String> cartItems = readCartItems();
        if (!cartItems.isEmpty()) {
            new MyOrder(cartItems);
        } else {
            JOptionPane.showMessageDialog(this, "You have no order now.", "Empty Order", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void openContacts(MainScreen mainScreen) {
        new Contacts(mainScreen); // Pass the reference to the Contacts constructor
    }

    private void goBack() {
        dispose(); // Close the MainScreen window
        new RestaurantManagementSystem(); // Open the WelcomeFrame
    }

    private List<String> readCartItems() {
        List<String> items = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(CART_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                items.add(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return items;
    }

    public static void main(String[] args) {
        new MainScreen();
    }
}
