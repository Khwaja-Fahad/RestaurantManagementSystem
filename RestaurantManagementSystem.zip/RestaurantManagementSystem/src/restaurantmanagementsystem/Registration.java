package restaurantmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Registration extends JFrame {
    private static final String REGISTRATION_FILE = "registration.txt";
    private RestaurantManagementSystem mainPage;

    public Registration(RestaurantManagementSystem mainPage) {
        this.mainPage = mainPage;
        setTitle("Registration");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color

        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(173, 216, 230)); // Light blue background color

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JButton registerButton = createStyledButton("Register");

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (registerUser(username, password)) {
                    JOptionPane.showMessageDialog(Registration.this, "Registration Successful!");
                    dispose(); // Close the RegistrationFrame
                    mainPage.setVisible(true); // Show the main page
                } else {
                    JOptionPane.showMessageDialog(Registration.this, "Registration Failed. Please try again.");
                }
            }
        });

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(registerButton);

        add(panel);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JButton createStyledButton(String buttonText) {
        JButton button = new JButton(buttonText);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(new Color(173, 216, 230)); // Light blue button color
        button.setForeground(Color.BLACK); // Set text color
        return button;
    }

    private boolean registerUser(String username, String password) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(REGISTRATION_FILE, true))) {
            bw.write(username + "," + password);
            bw.newLine();  // Add newline after writing user credentials
            return true; // Registration successful
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Registration failed
        }
    }
}
