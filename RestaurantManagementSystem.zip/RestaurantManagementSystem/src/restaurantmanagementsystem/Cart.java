package restaurantmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Cart extends JFrame {
    private static final String CART_FILE = "cart.txt";

    private MainScreen mainScreen; // Reference to the MainScreen

    public Cart(MainScreen mainScreen) {
        this.mainScreen = mainScreen; // Assign the reference

        setTitle("Cart");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color
        getContentPane().setLayout(new BorderLayout());

        JPanel cartItemsPanel = new JPanel();
        cartItemsPanel.setLayout(new BoxLayout(cartItemsPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(cartItemsPanel);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(173, 216, 230));

        JButton goBackButton = new JButton("Go Back");
        goBackButton.setBackground(new Color(173, 216, 230)); // Light blue button color
        goBackButton.setForeground(Color.BLACK); // Set text color
        goBackButton.addActionListener(e -> {
            dispose();
            if (mainScreen != null) {
                mainScreen.setVisible(true); // Show the MainScreen
            }
        });
        buttonPanel.add(goBackButton);

        JButton orderNowButton = new JButton("Order Now");
        orderNowButton.setBackground(new Color(173, 216, 230)); // Light blue button color
        orderNowButton.setForeground(Color.BLACK); // Set text color
        orderNowButton.addActionListener(e -> {
            // Transfer cart items to MyOrder
            List<String> cartItems = readCartItems();
            new MyOrder(cartItems).setVisible(true); // Show MyOrder with cart items
            dispose(); // Close the Cart window
        });
        buttonPanel.add(orderNowButton);

        JButton clearCartButton = new JButton("Clear Cart");
        clearCartButton.setBackground(new Color(173, 216, 230)); // Light blue button color
        clearCartButton.setForeground(Color.BLACK); // Set text color
        clearCartButton.addActionListener(e -> {
            clearCart();
            refreshCart(cartItemsPanel);
        });
        buttonPanel.add(clearCartButton);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);

        refreshCart(cartItemsPanel);
    }

    private void refreshCart(JPanel cartItemsPanel) {
        cartItemsPanel.removeAll();
        List<String> cartItems = readCartItems();
        if (cartItems.isEmpty()) {
            cartItemsPanel.add(new JLabel("Your cart is empty."));
        } else {
            for (String item : cartItems) {
                // Split the line into dish name and price
                String[] parts = item.split(",");
                if (parts.length == 2) {
                    String dishName = parts[0];
                    double price = Double.parseDouble(parts[1]);

                    // Create a JLabel to display the dish name and price
                    JLabel label = new JLabel(dishName + " - $" + price);
                    label.setForeground(Color.BLACK); // Set text color
                    cartItemsPanel.add(label);
                }
            }
        }
        cartItemsPanel.revalidate();
        cartItemsPanel.repaint();
    }

    private List<String> readCartItems() {
        List<String> items = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(CART_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                items.add(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return items;
    }

    private void clearCart() {
        try (FileWriter writer = new FileWriter(CART_FILE)) {
            writer.write(""); // Clear the cart file
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Cart(null);
    }
}
