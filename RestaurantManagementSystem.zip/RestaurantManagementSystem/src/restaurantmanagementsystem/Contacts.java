package restaurantmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Contacts extends JFrame {
    private MainScreen mainScreen; // Reference to MainScreen class

    public Contacts(MainScreen mainScreen) {
        this.mainScreen = mainScreen; // Assign the reference to the MainScreen instance

        setTitle("Contacts");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue background color
        setLayout(new BorderLayout()); // Use BorderLayout for better organization

        // Panel for contact information
        JPanel contactPanel = new JPanel();
        contactPanel.setLayout(new GridLayout(6, 2, 10, 10)); // 6 rows, 2 columns
        contactPanel.setBackground(new Color(240, 248, 255)); // Lighter background color

        // Phone number
        JLabel phoneLabel = new JLabel("Phone Number:");
        JTextField phoneField = new JTextField("+912345678");
        phoneField.setEditable(false); // Make it non-editable
        contactPanel.add(phoneLabel);
        contactPanel.add(phoneField);

        // Email
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField("restaurantContact@gmail.com");
        emailField.setEditable(false); // Make it non-editable
        contactPanel.add(emailLabel);
        contactPanel.add(emailField);

        // Facebook
        JLabel facebookLabel = new JLabel("Facebook:");
        JTextField facebookField = new JTextField("www.restaurantfacebook.com");
        facebookField.setEditable(false); // Make it non-editable
        contactPanel.add(facebookLabel);
        contactPanel.add(facebookField);

        // WhatsApp
        JLabel whatsappLabel = new JLabel("WhatsApp:");
        JTextField whatsappField = new JTextField("WhatsApp Number");
        whatsappField.setEditable(false); // Make it non-editable
        contactPanel.add(whatsappLabel);
        contactPanel.add(whatsappField);

        // Instagram
        JLabel instagramLabel = new JLabel("Instagram:");
        JTextField instagramField = new JTextField("Instagram Handle");
        instagramField.setEditable(false); // Make it non-editable
        contactPanel.add(instagramLabel);
        contactPanel.add(instagramField);

        // Follow on Pages
        JLabel followLabel = new JLabel("Follow on Pages:");
        JTextField followField = new JTextField("Other Social Media Links");
        followField.setEditable(false); // Make it non-editable
        contactPanel.add(followLabel);
        contactPanel.add(followField);

        add(contactPanel, BorderLayout.CENTER); // Add contact panel to center of JFrame

        // Panel for "Go Back" button
        JPanel buttonPanel = new JPanel();
        JButton goBackButton = new JButton("Go Back");
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the Contacts window
                mainScreen.setVisible(true); // Make the MainScreen window visible
            }
        });
        buttonPanel.add(goBackButton);
        buttonPanel.setBackground(new Color(240, 248, 255)); // Lighter background color
        add(buttonPanel, BorderLayout.SOUTH); // Add button panel to bottom of JFrame

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
